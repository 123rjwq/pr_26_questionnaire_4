package com.example.pr_26_questionnaire

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.RadioButton
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val radioButton = findViewById<RadioButton>(R.id.rbForMoney)
        val salaryBox = findViewById<LinearLayout>(R.id.salaryBox)
        val phoneEditText = findViewById<EditText>(R.id.phone)

        radioButton.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                salaryBox.visibility = View.VISIBLE
            } else {
                salaryBox.visibility = View.GONE
            }
        }

        // Добавление маски для номера телефона
        phoneEditText.addPhoneNumberMask()
    }
}

// Расширение для EditText
fun EditText.addPhoneNumberMask() {
    this.addTextChangedListener(object : TextWatcher {
        private var lastChar: String = ""

        override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            if (s.length > 1) {
                lastChar = s.subSequence(s.length - 1, s.length).toString()
            }
        }

        override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
            if (s.length > 0 && s.length != 4 && s.length != 8) {
                val last = s.subSequence(s.length - 1, s.length)
                if (last.toString() == "-") {
                    this@addPhoneNumberMask.text?.delete(s.length - 1, s.length)
                }
            }
            if (s.length == 3 || s.length == 7) {
                if (!lastChar.equals("-")) {
                    this@addPhoneNumberMask.append("-")
                } else {
                    this@addPhoneNumberMask.text?.delete(s.length - 1, s.length)
                }
            }
        }

        override fun afterTextChanged(s: Editable) {}
    })
}

